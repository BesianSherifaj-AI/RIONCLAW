<!-- topic:example -->
This is a placeholder tiny-prompt file. Replace its contents with a real
topic note when the schema needs one. Do not add new fields.
