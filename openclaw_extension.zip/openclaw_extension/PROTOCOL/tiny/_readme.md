# tiny/ — small context files

Each file in this folder is a minimal, topic-scoped prompt that VERIFIER
expands when the topic is relevant.

Rule: read-only during flow. Changes happen out-of-band.
