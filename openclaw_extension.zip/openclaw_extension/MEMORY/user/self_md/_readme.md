# self_md/ — user-provided .md files

Read-only in flow. Drop files here to give the VERIFIER extra context
about yourself. Format is free-form.
