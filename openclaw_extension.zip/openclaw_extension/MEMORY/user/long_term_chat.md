<!-- begin:long_term_chat -->
<!-- end:long_term_chat -->
